import Math

main = do
  print (add 2 3)
  print (multiply 4 5)
