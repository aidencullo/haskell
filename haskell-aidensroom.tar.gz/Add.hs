module Math.Adder where

add x y = 0
