-- Math.hs
module Math (module Math.Adder, module Math.Multiplier) where

import Math.Adder
import Math.Multiplier
