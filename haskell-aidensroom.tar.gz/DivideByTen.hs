module DivideByTen where

divideByTen :: (Floating a) => a -> a
divideByTen = (/10)
