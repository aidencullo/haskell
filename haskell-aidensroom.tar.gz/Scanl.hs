-- How many elements does it take for the sum of the square roots of all natural numbers to exceed 1000?

-- sumOfSquares :: Int
sumOfSquares = 
