module MultTwoWithNine where

multTwoWithNine :: (Num a) => a -> a -> a
multTwoWithNine x y = x * y * 9
