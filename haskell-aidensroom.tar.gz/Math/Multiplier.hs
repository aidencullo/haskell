-- Math/Multiplier.hs
module Math.Multiplier (multiply) where

multiply :: Int -> Int -> Int
multiply x y = x * y
