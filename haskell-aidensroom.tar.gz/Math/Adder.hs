-- Math/Adder.hs
module Math.Adder (add) where

add :: Int -> Int -> Int
add x y = x + y
