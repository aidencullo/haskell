-- a sample predicate

isEven :: Int -> Bool
isEven x = x `mod` 2 == 0
